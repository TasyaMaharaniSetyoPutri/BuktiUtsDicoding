package com.tasya.btsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvBts;
    private ArrayList<BtsArchitecture> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rvBts = findViewById(R.id.rv_bts);
        rvBts.setHasFixedSize(true);

        list.addAll(BtsData.getListData());

        showRecyclerList();
    }
    private void showRecyclerList() {
        rvBts.setLayoutManager(new LinearLayoutManager(this));
        ListBts listBts = new ListBts(list);
        rvBts.setAdapter(listBts);

        listBts.setOnItemClickCallback(new ListBts.OnItemClickCallback() {
            @Override
            public void onItemClicked(BtsArchitecture data) {

                showSelectedData(data);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, datadiri.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }

    public void showSelectedData(BtsArchitecture nw) {
        Intent detailIntent = new Intent(MainActivity.this, DetailBts.class);
        detailIntent.putExtra(DetailBts.EXTRA_IMG, nw.getPhoto());
        detailIntent.putExtra(DetailBts.EXTRA_FULLNAME, nw.getFullName());
        detailIntent.putExtra(DetailBts.EXTRA_NICKNAME, nw.getNickName());
        detailIntent.putExtra(DetailBts.EXTRA_DETAIL, nw.getDetail());
        detailIntent.putExtra(DetailBts.EXTRA_LAHIR, nw.getLahir());
        detailIntent.putExtra(DetailBts.EXTRA_POSISI, nw.getPosisi());
        startActivity(detailIntent);
    }
}
