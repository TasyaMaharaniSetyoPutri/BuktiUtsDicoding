package com.tasya.btsapp;

import java.util.ArrayList;

public class BtsData {

    private static String[] btsFullName = {
            "Kim Tae-hyung",
            "Min Yoon-gi",
            "Jeon Jeong-guk ",
            "Park Ji-min",
            "Kim Seok-jin",
            "Kim Nam-joon",
            "Jung Ho-seok",
            "TATA",
            "SHOOKY",
            "COOKY"


    };

    private static String[] btsNickName = {
            "V",
            "Suga",
            "Jungkook",
            "Jimin",
            "Jin",
            "RM",
            "J",
            "TATA",
            "SHOOKY",
            "COOKY"

    };
    private static String[] btsDetail = {
            "Kim Tae-hyung (Hangul: 김태형,[2] Chinese: 金泰亨;Jīn Tàihēng, Japan: キム テヒョン;Kimu Tehyon) lebih dikenal dengan nama panggungnya V, adalah penyanyi, penulis lagu, dan aktor asal Korea Selatan. Ia merupakan anggota dari grup vokal pria Korea Selatan BTS",
            "Min Yoon-gi (lahir 9 Maret 1993; umur 26 tahun; Hangul: 민윤기), lebih dikenal sebagai Suga, adalah seorang penyanyi, penulis lagu, dan produser rekaman. Ia adalah anggota dari grup idola pria Korea Selatan, BTS, yang dikelola oleh Big Hit Entertainment. Pada bulan Agustus 2016, ia merilis album solo pertamanya berupa mixtape yang bertajuk Agust D, dengan menggunakan nama Agust D.",
            "Jeon Jeong-guk (Hangeul: 전정국;lahir 1 September 1997; umur 22 tahun) atau dikenal dengan nama panggung Jungkook adalah seorang penyanyi dan anggota boy band Korea Selatan yaitu BTS atau Bangtan Boys, atau bisa juga disebut Beyond The Scene, yang dibentuk di bawah naungan Big Hit Entertainment pada tahun 2013. Posisinya adalah main vocalist (vokalis utama), lead dancer (penari), sub-rapper, dan center",
            "Park Ji-min (Hangeul: 박지민[1]; lahir 13 Oktober 1995; umur 24 tahun) atau dikenal dengan nama panggung Jimin adalah salah satu anggota BTS atau Bangtan Sonyeondan yang berasal dari Korea Selatan, dengan posisi vokalis (lead vocal) dan penari utama (main dancer)[2] yang berada dibawah naungan agensi Big Hit Entertainment.",
            "Jin (nama asli: Kim Seok Jin [1] 김석 진, 4 Desember 1992) adalah penyanyi dan penulis lagu dari Korea Selatan.[2][3] Dia adalah member tertua dan vokalis dari boygrup di Korea Selatan, BTS.[3] Sebagai seorang penulis lagu, dia mempunyai lima lagu terakreditasi namanya oleh Korea Music Copyright Association.",
            "Kim Nam-joon (Hangul: 김남준; lahir 12 September 1994; umur 25 tahun),[2] atau dikenal juga sebagai RM (sebelumnya Rap Monster), adalah seorang idol rapper dan penyanyi sekaligus penulis lagu asal Korea Selatan. Dia adalah pemimpin dan rapper utama dari boy band asal Korea Selatan yaitu Bangtan Boys, yang dibentuk di bawah naungan Big Hit Entertainment.",
            "Jung Ho-seok (Hangul: 정호석; lahir 18 Februari 1994; umur 25 tahun), lebih dikenal dengan nama \"J-Hope\", adalah seorang rapper, penari, penyanyi, penulis lagu, dan produser rekaman dari Korea Selatan. Pada tahun 2013, J-Hope memulai debutnya sebagai anggota boy band dari Korea Selatan BTS, dikelola di bawah Big Hit Entertainment. Sebagai salah satu komposer utama untuk grup, ia memiliki 77 lagu yang terakreditasi atas nama-nya oleh Korea Music Copyright Association.\n" + "J-Hope merilis mixtape pertamanya, Hope World, di seluruh dunia pada tanggal 1 Maret 2018. Album ini diterima dengan sambutan positif, dan debutnya di peringkat 63 membuatnya menjadi artis solo K-pop tertinggi di Billboard 200.\n",
            "Tata, karakter buatan Kim Taehyung alias V bisa dibilang adalah awal mula terbentuknya ide BT21. Tata merupakan makhluk dari planet BT yang selalu penasaran tentang apapun di luar planetnya. Ia sangat ingin menjadi superstars di bumi setelah secara tak sengaja mendarat di bumi dalam perjalanannya.\n" + "Tata pun memulai perjalanannya untuk menjadi seorang bintang bersama 6 member lain dalam sebuah grup bernama BT21 yang akan menjadi bintang dunia, seperti itulah awal mula BT21 dimulai. Sama seperti pembuatnya, V, si Tata ini sangat percaya diri dan selalu menyebut dirinya tampan dengan badan yang kecil dan kepalanya yang membentuk simbol hati berwarna merah\n",
            "Menjadi member yang paling galak menurut member lain, Suga pun menuangkannya dalam karakter Shooky. Shooky adalah biskuit kecil yang selalu bilang kalau ia sangat manis, tapi sebenarnya ia adalah tokoh evil dan antagonis di BT21. Shooky berteman dengan karakter buatan Jungkook. Dalam stiker yang disediakan, sering terlihat mereka sedang bersama, tapi mereka juga sangat suka bertengkar.\n" + "Motto hidupnya \"Aku bukan cookie, aku adalah Shooky yang enak!!\". Meski mottonya seperti itu, tapi Shooky sangat takut dengan susu, kalau melihat susu ia membayangkan dirinya dicelup ke dalam susu lalu dimakan\n",
            "Meski berwarna pink, tapi ternyata Cooky bukan sosok yang hanya bersantai untuk mempercantik diri. Kelinci merah muda buatan sang maknae, Jungkook ini rajin banget melakukan work out karena ia bermimpi untuk memiliki tubuh yang berotot. Ciri khas Cooky yaitu mempunyai alis yang unik dan bokong yang berbentuk hati.\n" + "Setiap hari yang dilakukan Cooky untuk memenuhi impiannya adalah lari 120 menit, push up 400 kali, mengecek otot dan latihan menggambar alis selama 100 menit. Baru tau deh kalo gambar alis bisa bikin otot besar hehee.\n" + "Cooky ini suka banget berkhayal, ia bahkan sering membayangkan kalau ia bisa mengalahkan Shooky si antagonis.\n"


    };
    private static String[] btsLahir = {
           "Daegu, Korea Selatan, 30 Desember 1995",
            "Daegu, Korea Selatan, 9 Maret 1993",
            "Busan, Korea Selatan, 1 September 1997",
            "Busan, Korea Selatan, 13 Oktober 1995",
            "Gwacheon, Korea Selatan, 4 Desember 1992",
            "Goyang, Korea Selatan, 12 September 1994",
            "Gwangju, Korea Selatan, 18 Februari 1994",
            "Daegu, Korea Selatan, 30 Desember 1995",
            "Daegu, Korea Selatan, 9 Maret 1993",
            "Busan, Korea Selatan, 1 September 1997"



    };
    private static String[] btsPosisi = {
            "Vokalis",
            "Rapper",
            "Maknae, Vokalis, Rapper",
            "Vokalis",
            "Vokalis, Visual",
            "Leader, Rapper",
            "Rapper",
            "Vokalis",
            "Rapper",
            "Maknae, Vokalis, Rapper"


    };
    private static int[] photo = {
            R.drawable.kim,
            R.drawable.suga,
            R.drawable.jungkook,
            R.drawable.jimin,
            R.drawable.jin,
            R.drawable.rm,
            R.drawable.j,
            R.drawable.tata,
            R.drawable.shooky,
            R.drawable.cooky

    };

    static ArrayList<BtsArchitecture> getListData() {
        ArrayList<BtsArchitecture> list = new ArrayList<>();
        for (int position = 0; position < btsNickName.length; position++) {
            BtsArchitecture nw = new BtsArchitecture();
            nw.setFullName(btsFullName[position]);
            nw.setNickName(btsNickName[position]);
            nw.setDetail(btsDetail[position]);
            nw.setLahir(btsLahir[position]);
            nw.setPosisi(btsPosisi[position]);
            nw.setPhoto(photo[position]);
            list.add(nw);
        }

        return list;
    }
}
