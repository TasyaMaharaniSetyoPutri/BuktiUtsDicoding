package com.tasya.btsapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailBts extends AppCompatActivity{
    public static final String EXTRA_FULLNAME = "extra_fullname";
    public static final String EXTRA_NICKNAME= "extra_nickname";
    public static final String EXTRA_DETAIL= "extra_detail";
    public static final String EXTRA_LAHIR= "extra_lahir";
    public static final String EXTRA_POSISI= "extra_posisi";
    public static final String EXTRA_IMG= "extra_img";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageView imgBts;
        TextView tvFullName, tvNickName, tvDetail, tvLahir, tvPosisi;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.bts_detail);
        imgBts = findViewById(R.id.tv_bts_photo);
        tvFullName = findViewById(R.id.tv_full_name);
        tvNickName = findViewById(R.id.tv_nick_name);
        tvDetail = findViewById(R.id.tv_detail);
        tvLahir = findViewById(R.id.tv_lahir);
        tvPosisi = findViewById(R.id.tv_posisi);

        String full = getIntent().getStringExtra(EXTRA_FULLNAME),
                nick = getIntent().getStringExtra(EXTRA_NICKNAME),
                detail = getIntent().getStringExtra(EXTRA_DETAIL),
                lahir = getIntent().getStringExtra(EXTRA_LAHIR),
                posisi = getIntent().getStringExtra(EXTRA_POSISI);
        int photo = getIntent().getIntExtra(EXTRA_IMG,0);
        Bitmap bmp = BitmapFactory.decodeResource(getResources(), photo);
        imgBts.setImageBitmap(bmp);
        tvFullName.setText(full);
        tvNickName.setText(nick);
        tvLahir.setText(lahir);
        tvPosisi.setText(posisi);
        tvDetail.setText(detail);
    }

}
