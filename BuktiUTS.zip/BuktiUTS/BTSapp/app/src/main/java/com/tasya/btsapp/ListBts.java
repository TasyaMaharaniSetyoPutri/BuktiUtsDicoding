package com.tasya.btsapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListBts extends RecyclerView.Adapter<ListBts.ListViewHolder>{

    private ArrayList<BtsArchitecture> listBts;

    private OnItemClickCallback onItemClickCallback;

    public ListBts(ArrayList<BtsArchitecture> list) {
        this.listBts = list;
    }

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_bts, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, int position) {
        BtsArchitecture nw = listBts.get(position);

        Glide.with(holder.itemView.getContext())
                .load(nw.getPhoto())
                .apply(new RequestOptions().override(60, 60))
                .into(holder.imgBts);
        holder.tvNickName.setText(nw.getNickName());
        holder.tvLahir.setText(nw.getLahir());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(listBts.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listBts.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder{
        ImageView imgBts;
        TextView tvFullName, tvNickName, tvDetail, tvLahir, tvPosisi;


        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgBts = itemView.findViewById(R.id.tv_bts_photo);
            tvFullName = itemView.findViewById(R.id.tv_full_name);
            tvNickName = itemView.findViewById(R.id.tv_nick_name);
            tvDetail = itemView.findViewById(R.id.tv_detail);
            tvLahir = itemView.findViewById(R.id.tv_lahir);
            tvPosisi = itemView.findViewById(R.id.tv_posisi);

        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(BtsArchitecture data);
    }
}
